﻿angular.module('umbraco')
    .controller('ncFootprint.Backoffice.BaseDashboard.Controller',
        function ($scope, $routeParams) {

        }
    );